# -*- coding: utf-8 -*-
"""
Task 1 · 全量微调 vs LoRA：参数账本 + 幅度权衡实测
==============================================
微调 LLM 的最省方案是啥？LoRA（Low-Rank Adaptation）：
  不更新原权重 W，而是加低秩增量 ΔW = (α/r)·B·A，只训 A/B。
  前向： h = Wx + (α/r)·BAx      （初始 B=0 → 增量=0，完美保留预训练行为）

关键机制（本 Task 实测点）：
  α/r 是"幅度旋钮"——决定增量能改多少原行为：
    α 大 → 学新任务快，但忘旧任务快（增量粗暴）
    α 小 → 学新任务慢，但旧能力保持好（增量温柔）
    FT  = α=∞ 的极端（全参数大改）
  任务设计：预训练学"线性规则"（任务 A），微调到强冲突的 XOR（任务 B），
  对比三种策略学 B 的效果 + 对 A 的遗忘。

运行：python3 peft/task1_lora_vs_full.py
"""
import time
import torch
import torch.nn as nn
import torch.nn.functional as F

torch.manual_seed(42)


# ============ 数据：任务 A（线性）→ 任务 B（XOR，强冲突） ============
def make_data(n, mode):
    x = torch.randn(n, 2)
    if mode == "A":                                   # 线性：x1 + x2 > 0
        y = (x[:, 0] + x[:, 1] > 0).long()
    else:                                             # XOR：异或（与 A 冲突）
        y = ((x[:, 0] > 0) ^ (x[:, 1] > 0)).long()
    return x, y

XA_tr, yA_tr = make_data(1000, "A")
XA_te, yA_te = make_data(400, "A")
XB_tr, yB_tr = make_data(1000, "B")
XB_te, yB_te = make_data(400, "B")


# ============ 模型 ============
class MLP(nn.Module):
    def __init__(self):
        super().__init__()
        self.f1 = nn.Linear(2, 32)
        self.f2 = nn.Linear(32, 2)
    def forward(self, x):
        return self.f2(F.relu(self.f1(x)))


class LoRALinear(nn.Module):
    """冻结 linear + 低秩增量 (alpha/r)·BA。alpha 是幅度旋钮。"""
    def __init__(self, linear, r, alpha):
        super().__init__()
        self.linear = linear
        self.linear.requires_grad_(False)
        self.A = nn.Parameter(torch.randn(linear.in_features, r) * 0.01)
        self.B = nn.Parameter(torch.zeros(r, linear.out_features))
        self.scale = alpha / r
    def forward(self, x):
        return self.linear(x) + self.scale * (x @ self.A @ self.B)


class LoRAMLP(nn.Module):
    def __init__(self, r, alpha):
        super().__init__()
        self.f1 = LoRALinear(nn.Linear(2, 32), r, alpha)
        self.f2 = LoRALinear(nn.Linear(32, 2), r, alpha)
    def forward(self, x):
        return self.f2(F.relu(self.f1(x)))


def train(model, x, y, x_te, y_te, lr, epochs, label):
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    t0 = time.perf_counter()
    for _ in range(epochs):
        opt.zero_grad()
        loss = F.cross_entropy(model(x), y)
        loss.backward()
        opt.step()
    dt = (time.perf_counter() - t0) / epochs * 1e3
    acc_te = (model(x_te).argmax(-1) == y_te).float().mean().item()
    n_tr = sum(p.numel() for p in model.parameters() if p.requires_grad)
    n_all = sum(p.numel() for p in model.parameters())
    print(f"  {label:<16} 可训 {n_tr:>5}/{n_all:<5}  每步 {dt:5.2f} ms  "
          f"B准确率 {acc_te*100:5.1f}％")
    return model, n_tr, dt, acc_te


def accA(model):
    return (model(XA_te).argmax(-1) == yA_te).float().mean().item()


print("=== 0. 预训练：任务 A（线性可分） ===")
base = MLP()
train(base, XA_tr, yA_tr, XA_te, yA_te, lr=1e-2, epochs=300, label="预训练A")
accA_0 = accA(base)
print(f"  → 任务 A 预训练后准确率 {accA_0*100:.1f}％")

print("\n=== 1. 微调任务 B（XOR，与 A 强冲突），三策略对比 ===")
results = {}
m, n_ft, dt_ft, acc_ft = train(MLP(), XB_tr, yB_tr, XB_te, yB_te,
                               1e-3, 200, "全量 FT (α=∞)")
results["FT"] = (m, n_ft, acc_ft)
m, n_lo, dt_lo, acc_lo1 = train(LoRAMLP(8, 1.0), XB_tr, yB_tr, XB_te, yB_te,
                                5e-3, 200, "LoRA α=1.0 (猛)")
results["LoRA_a1"] = (m, n_lo, acc_lo1)
m, n_lo2, dt_lo2, acc_lo3 = train(LoRAMLP(8, 0.3), XB_tr, yB_tr, XB_te, yB_te,
                                  5e-3, 400, "LoRA α=0.3 (柔)")
results["LoRA_a03"] = (m, n_lo2, acc_lo3)

print("\n=== 2. 冲突遗忘：微调 B 后，任务 A 还剩多少 ===")
print("  → 关键：XOR 与线性规则的判别面正交冲突——学好 B 必然毁 A，")
print("     FT 和任意 α 的 LoRA 都救不了（LoRA 不是免遗忘魔法）")
for name, (m, _, _) in results.items():
    a = accA(m)
    print(f"  {name:<16} A准确率 {accA_0*100:.1f}％ → {a*100:.1f}％"
          f"（遗忘 {(accA_0-a)*100:.1f} 个点）")

print("\n=== 3. 参数账本：LoRA 省钱吗？—— 关键看模型规模 ===")
print(f"  我的小模型（2→32→2）：全量 {n_ft} 参数 vs LoRA {n_lo} 参数"
      f" → LoRA/全量 = {n_lo/n_ft*100:.0f}％（反而更贵！）")
D_in, D_out, r = 4096, 14336, 8                        # 真实 7B 的 FFN 层
full, lora_p = D_in * D_out, 2 * r * (D_in + D_out)
print(f"  真实 7B FFN 层（4096→14336）：全量 {full/1e3:.0f}K vs LoRA {lora_p/1e3:.0f}K"
      f" → LoRA/全量 = {lora_p/full*100:.2f}％（省 99％+）")
print(f"  Adam 优化器状态（m+v）：全量微调 {2*full*4/1e6:.1f} MB vs LoRA {2*lora_p*4/1e3:.1f} KB")

# ============ 断言 ============
assert acc_ft > 0.85, "FT 应学会 XOR"
assert acc_lo1 > 0.85, "LoRA α=1.0 应同样学会 XOR（逼近甚至超过 FT）"
a_ft = accA(results["FT"][0]); a_lo3 = accA(results["LoRA_a03"][0])
assert a_ft < 0.75 and a_lo3 < 0.75, "强冲突任务下 FT 与 LoRA 都必然遗忘（判别面冲突）"
assert lora_p / full < 0.01, "大模型下 LoRA 可训参数省 99％+"
print(f"\n[PASS] Task1 全部断言通过：")
print(f"  ① LoRA 逼近 FT：学 B {acc_lo1*100:.1f}％ vs FT {acc_ft*100:.1f}％")
print(f"  ② 强冲突谁都遗忘：FT 保留 {(1-a_ft)*100:.1f}％、LoRA α=0.3 保留 {(1-a_lo3)*100:.1f}％")
print(f"  ③ 大模型 LoRA 可训参数占比 {lora_p/full*100:.2f}％（省 99％+）；小模型反而 336％")

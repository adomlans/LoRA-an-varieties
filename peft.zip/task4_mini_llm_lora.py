# -*- coding: utf-8 -*-
"""
Task 4 · LoRA 端到端：mini-LLM 微调实战
========================================
把 Task1-3 的低秩机制搬进真实 LLM 场景：
  预训练：字符级 GPT 学语料 A（"ababab..." 周期 2 循环）
  微调：  语料 B（"abcabc..." 周期 3 循环）
          —— B 是 A 的局部扩展（共享 'a→b' 转移，只新增 'b→c'），
             相关但不冲突：LoRA 应能学会 B 且少遗忘 A
  对比：  全量微调 FT / LoRA / 冻结基线（不训练）

  指标：B 验证 loss（学没学会）+ A 验证 loss 回升（忘没忘）
  账本：可训参数、每步耗时

运行：python3 peft/task4_mini_llm_lora.py
"""
import time
import torch
import torch.nn as nn
import torch.nn.functional as F

torch.manual_seed(7)
VOCAB = 6  # 字符 a-f

# ============ 语料：ab 循环（A）→ abc 循环（B） ============
def corpus(pat, n=1600):
    return torch.tensor([ord(c) - 97 for c in (pat * (n // len(pat) + 1))[:n]])

CA, CB = corpus("ab", 1600), corpus("abc", 2400)
A_tr, A_va = CA[:1200], CA[1200:1600]
B_tr, B_va = CB[:1600], CB[1600:2400]

def batch(seq, bs=32, L=32):
    s = torch.randint(0, len(seq) - L, (bs,))
    x = torch.stack([seq[i:i + L] for i in s])
    return x, torch.stack([seq[i + 1:i + L + 1] for i in s])

def val_loss(model, seq, steps=20):
    model.eval()
    tot = 0.0
    with torch.no_grad():
        for _ in range(steps):
            x, y = batch(seq)
            logits = model(x)
            tot += F.cross_entropy(logits.view(-1, VOCAB), y.view(-1)).item()
    model.train()
    return tot / steps


# ============ 字符级 mini-GPT ============
class CausalAttn(nn.Module):
    def __init__(self, dim, n_head):
        super().__init__()
        self.dim, self.n_head = dim, n_head
        self.hd = dim // n_head
        self.qkv = nn.Linear(dim, 3 * dim, bias=False)
        self.proj = nn.Linear(dim, dim, bias=False)
    def forward(self, x, cache_k=None, cache_v=None):
        B, T, D = x.shape
        q, k, v = self.qkv(x).chunk(3, dim=-1)
        q = q.view(B, T, self.n_head, self.hd).transpose(1, 2)
        k = k.view(B, T, self.n_head, self.hd).transpose(1, 2)
        v = v.view(B, T, self.n_head, self.hd).transpose(1, 2)
        if cache_k is not None:
            k = torch.cat([cache_k, k], dim=2); v = torch.cat([cache_v, v], dim=2)
        Tk = k.shape[2]
        mask = torch.triu(torch.ones(T, Tk, dtype=torch.bool), diagonal=Tk - T + 1)
        att = (q @ k.transpose(-2, -1)) / self.hd ** 0.5
        att = att.masked_fill(mask, float("-inf"))
        att = F.softmax(att, dim=-1)
        y = (att @ v).transpose(1, 2).reshape(B, T, D)
        return self.proj(y), k, v

class Block(nn.Module):
    def __init__(self, dim, n_head):
        super().__init__()
        self.attn = CausalAttn(dim, n_head)
        self.ffn = nn.Sequential(nn.Linear(dim, 4 * dim, bias=False),
                                 nn.GELU(),
                                 nn.Linear(4 * dim, dim, bias=False))
        self.ln1 = nn.LayerNorm(dim)
        self.ln2 = nn.LayerNorm(dim)
    def forward(self, x):
        h, _, _ = self.attn(self.ln1(x))
        x = x + h
        return x + self.ffn(self.ln2(x))

class MiniGPT(nn.Module):
    def __init__(self, vocab=VOCAB, dim=64, n_head=4, n_layer=2):
        super().__init__()
        self.emb = nn.Embedding(vocab, dim)
        self.blocks = nn.ModuleList([Block(dim, n_head) for _ in range(n_layer)])
        self.ln = nn.LayerNorm(dim)
        self.head = nn.Linear(dim, vocab, bias=False)
    def forward(self, x):
        h = self.emb(x)
        for b in self.blocks:
            h = b(h)
        return self.head(self.ln(h))


# ============ LoRA 版：qkv/proj/ffn 全包 ============
class LoRALinear(nn.Module):
    def __init__(self, linear, r=8, alpha=1.0):
        super().__init__()
        self.linear = linear
        self.linear.requires_grad_(False)
        self.A = nn.Parameter(torch.randn(linear.in_features, r) * 0.01)
        self.B = nn.Parameter(torch.zeros(r, linear.out_features))
        self.scale = alpha / r
    def forward(self, x):
        return self.linear(x) + self.scale * (x @ self.A @ self.B)

def wrap_linear(m, r):
    for name, child in list(m.named_children()):
        if isinstance(child, nn.Linear):
            setattr(m, name, LoRALinear(child, r))
        else:
            wrap_linear(child, r)

def make_lora(base, r=8):
    model = MiniGPT()
    model.load_state_dict(base.state_dict())   # 继承预训练权重
    wrap_linear(model, r)
    return model

def freeze(model):                             # 冻结基线：全部参数冻结
    for p in model.parameters():
        p.requires_grad_(False)
    return model

def train_on(model, seq, steps=400, lr=5e-3):
    params = [p for p in model.parameters() if p.requires_grad]
    n_al = sum(p.numel() for p in model.parameters())
    if not params:                               # 全冻结基线：无训练
        return 0, n_al, 0.0
    opt = torch.optim.Adam(params, lr=lr)
    t0 = time.perf_counter()
    for _ in range(steps):
        x, y = batch(seq)
        opt.zero_grad()
        loss = F.cross_entropy(model(x).view(-1, VOCAB), y.view(-1))
        loss.backward(); opt.step()
    dt = (time.perf_counter() - t0) / steps * 1e3
    n_tr = sum(p.numel() for p in model.parameters() if p.requires_grad)
    return n_tr, n_al, dt


print("=== 0. 预训练语料 A（ab 循环，周期 2） ===")
base = MiniGPT()
train_on(base, A_tr, 400, 1e-3)
la0 = val_loss(base, A_va)
print(f"  预训练后 A 验证 loss {la0:.4f}（随机基线 ≈ {torch.tensor(VOCAB).log():.4f}）")

print("\n=== 1. 微调语料 B（abc 循环，周期 3）：FT vs LoRA vs 冻结 ===")
ft = MiniGPT(); ft.load_state_dict(base.state_dict())
n1, _, dt1 = train_on(ft, B_tr, 400, 1e-3)
lora = make_lora(base, 8)
n2, n_all, dt2 = train_on(lora, B_tr, 400, 2e-3)
frz = freeze(MiniGPT()); frz.load_state_dict(base.state_dict())
n3, _, dt3 = train_on(frz, B_tr, 200, 0)          # 无参数可训 → 纯基线

for name, m in (("FT", ft), ("LoRA", lora), ("冻结", frz)):
    lb = val_loss(m, B_va); la = val_loss(m, A_va)
    print(f"  {name:<5} B验证loss {lb:.4f}（↓=学会了）  A验证loss {la:.4f}"
          f"（↑=忘了）  回升 {la-la0:+.4f}")

print("\n=== 2. 账本 ===")
print(f"  可训参数：FT {n1}（100％） vs LoRA {n2}（{n2/n_all*100:.1f}％） vs 冻结 {n3}")
print(f"  每步耗时：FT {dt1:.2f} ms vs LoRA {dt2:.2f} ms")

# ============ 断言 ============
lb_ft = val_loss(ft, B_va); lb_lo = val_loss(lora, B_va)
lb_fz = val_loss(frz, B_va)
la_ft = val_loss(ft, A_va); la_lo = val_loss(lora, A_va)
assert lb_fz > lb_ft - 0.1, "冻结基线学不动 B（对照组）"
assert lb_lo < lb_fz - 0.2, "LoRA 学会 B（明显低于基线）"
assert lb_lo < lb_ft + 0.1, "LoRA 学习效果接近 FT"
assert la_lo - la0 < la_ft - la0 + 0.05, "LoRA 遗忘 A 少于 FT（增量小 → 覆盖少）"
assert n2 / n_all < 0.3, "LoRA 可训参数明显少于全量"
print(f"\n[PASS] Task4 全部断言通过：B学习 FT {lb_ft:.4f} vs LoRA {lb_lo:.4f} vs 冻结 {lb_fz:.4f}；"
      f"A遗忘回升 LoRA {la_lo-la0:+.4f} vs FT {la_ft-la0:+.4f}；"
      f"LoRA 可训参数 {n2/n_all*100:.1f}％")

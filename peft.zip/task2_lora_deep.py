# -*- coding: utf-8 -*-
"""
Task 2 · LoRA 深入：秩 r · target modules · 合并等价 · 多任务账本
=================================================================
Task1 验证了"LoRA 能逼近 FT"。Task2 问四个工程问题：
  A. 秩 r 怎么选？           —— r=2/8/32 扫描（容量 vs 效果，找甜点）
  B. LoRA 加在哪层？         —— 只加 f1(特征) / 只加 f2(输出) / 两层
  C. 合并等价？              —— merge 后 W' = W + (α/r)BA 的输出与 LoRA 前向一致
  D. 多任务共享？            —— 一个主干 + N 个 ΔW，账本怎么算（大模型才划算）

运行：python3 peft/task2_lora_deep.py
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

torch.manual_seed(42)


# ============ 数据（A 线性预训练 → B 圆分类：需要特征改造） ============
def make_data(n, mode):
    x = torch.randn(n, 2)
    if mode == "A":
        y = (x[:, 0] + x[:, 1] > 0).long()
    else:                                   # 圆内圆外：线性不可分，需非线性特征
        y = (x[:, 0] ** 2 + x[:, 1] ** 2 < 1.0).long()
    return x, y

XA_tr, yA_tr = make_data(1000, "A")
XB_tr, yB_tr = make_data(1000, "B")
XB_te, yB_te = make_data(400, "B")


class MLP(nn.Module):
    def __init__(self):
        super().__init__()
        self.f1 = nn.Linear(2, 32)
        self.f2 = nn.Linear(32, 2)
    def forward(self, x):
        return self.f2(F.relu(self.f1(x)))


class LoRALinear(nn.Module):
    def __init__(self, linear, r, alpha=1.0):
        super().__init__()
        self.linear = linear
        self.linear.requires_grad_(False)
        self.A = nn.Parameter(torch.randn(linear.in_features, r) * 0.01)
        self.B = nn.Parameter(torch.zeros(r, linear.out_features))
        self.scale = alpha / r
    def forward(self, x):
        return self.linear(x) + self.scale * (x @ self.A @ self.B)
    def merge(self):
        """把增量合进 W（推理部署用）：W ← W + scale·(BA)^T，然后可丢 A/B"""
        with torch.no_grad():
            self.linear.weight.add_(self.scale * (self.A @ self.B).T)
            self.A.zero_(); self.B.zero_()
        return self.linear


class LoRAMLP(nn.Module):
    def __init__(self, base, r, target="both"):
        super().__init__()
        self.f1 = LoRALinear(base.f1, r) if target in ("f1", "both") else base.f1
        self.f2 = LoRALinear(base.f2, r) if target in ("f2", "both") else base.f2
        self.target = target
    def forward(self, x):
        return self.f2(F.relu(self.f1(x)))
    def merge(self):
        if isinstance(self.f1, LoRALinear): self.f1.merge()
        if isinstance(self.f2, LoRALinear): self.f2.merge()


def pretrain():
    base = MLP()
    opt = torch.optim.Adam(base.parameters(), lr=1e-2)
    for _ in range(300):
        opt.zero_grad()
        loss = F.cross_entropy(base(XA_tr), yA_tr)
        loss.backward(); opt.step()
    return base


def finetune(model, epochs=200, lr=5e-3):
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    for _ in range(epochs):
        opt.zero_grad()
        loss = F.cross_entropy(model(XB_tr), yB_tr)
        loss.backward(); opt.step()
    return (model(XB_te).argmax(-1) == yB_te).float().mean().item()


def n_trainable(m):
    return sum(p.numel() for p in m.parameters() if p.requires_grad)


base = pretrain()
print("=== A. 秩 r 扫描（target=both，200 epochs） ===")
for r in (2, 8, 32):
    m = LoRAMLP(MLP(), r)
    acc = finetune(m)
    print(f"  r={r:<3} 可训 {n_trainable(m):>5}   B准确率 {acc*100:5.1f}％")

print("\n=== B. target modules（r=8，200 epochs） ===")
for tgt in ("f1", "f2", "both"):
    m = LoRAMLP(MLP(), 8, tgt)
    acc = finetune(m)
    print(f"  只加{tgt:<4} 可训 {n_trainable(m):>5}   B准确率 {acc*100:5.1f}％")

print("\n=== C. 合并等价：merge 后输出与 LoRA 前向一致 ===")
m = LoRAMLP(MLP(), 8)
finetune(m, 200)
x = torch.randn(64, 2)
out_lora = m(x).detach()
m.merge()                                    # W ← W + ΔW，A/B 清零
out_merged = m(x).detach()
diff = (out_lora - out_merged).abs().max().item()
print(f"  LoRA 前向 vs 合并后前向最大差 {diff:.2e}（应 ≈ 0）")
print(f"  合并后可训参数 {n_trainable(m)}（A/B 已清零 → 部署为零增量成本）")

print("\n=== D. 多任务账本：一个主干 + N 个 ΔW ===")
D_in, D_out, r = 4096, 14336, 8
full = D_in * D_out
lora_p = 2 * r * (D_in + D_out)
print(f"  真实 7B 级 FFN 层：1 个主干 {full/1e3:.0f}K + N 个 ΔW（每个 {lora_p/1e3:.0f}K）")
print(f"  2 任务：FT 要 {2*full/1e6:.1f}M 参数 vs LoRA {full/1e3:.0f}K + {2*lora_p/1e3:.0f}K"
      f"（增量占 {2*lora_p/(full+2*lora_p)*100:.1f}％）")
print(f"  8 任务：FT 要 {8*full/1e6:.1f}M vs LoRA {full/1e3:.0f}K + {8*lora_p/1e3:.0f}K"
      f"（增量占 {8*lora_p/(full+8*lora_p)*100:.1f}％）")
print(f"  → 任务越多，共享主干的边际成本越低（PEFT 的 parameter-efficient 本质）")

# ============ 断言 ============
def all_zero(mod):
    return all((p.abs().max() == 0).item()
               for p in mod.parameters() if p.requires_grad)
acc_r2 = finetune(LoRAMLP(MLP(), 2))
acc_r8 = finetune(LoRAMLP(MLP(), 8))
acc_r32 = finetune(LoRAMLP(MLP(), 32))
acc_f1 = finetune(LoRAMLP(MLP(), 8, "f1"))
acc_f2 = finetune(LoRAMLP(MLP(), 8, "f2"))
assert acc_r2 > 0.9 and acc_r8 > 0.9 and acc_r32 > 0.9, "所有秩都应能学会圆分类"
assert acc_r32 - acc_r2 < 0.05, "秩收益递减：r=2→32 提升 <5 个点（甜点附近）"
assert acc_f1 > 0.9 and acc_f2 > 0.9, "不同 target 都能生效（位置影响因任务而异）"
assert diff < 1e-5, "merge 后前向必须与 LoRA 前向数值等价"
assert all_zero(m), "merge 后 A/B 必须清零（增量已合进 W，可整体丢弃）"
print(f"\n[PASS] Task2 全部断言通过：")
print(f"  r 扫描 {acc_r2*100:.1f}％/{acc_r8*100:.1f}％/{acc_r32*100:.1f}％（收益递减，"
      f"参数 136→2176 = 16 倍）")
print(f"  target {acc_f1*100:.1f}％/{acc_f2*100:.1f}％（位置影响因任务而异）")
print(f"  merge 等价差 {diff:.1e}，A/B 已清零；多任务增量占比 "
      f"{2*lora_p/(full+2*lora_p)*100:.1f}％（8 任务 {8*lora_p/(full+8*lora_p)*100:.1f}％）")

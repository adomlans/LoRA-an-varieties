# -*- coding: utf-8 -*-
"""
Task 3 · LoRA 变体：DoRA · QLoRA 模拟 · AdaLoRA 秩分配
========================================================
Task2 建立了 LoRA 基线。Task3 实测三个工业级变体：
  A. DoRA：权重分解 W = m·(V/‖V‖)，方向增量用 LoRA 学，幅度 m 单独学
     —— 模拟全量微调的"方向/幅度解耦"动力学，同 r 下更强更稳
  B. QLoRA：主干 INT4 量化存储（反量化前向），LoRA 增量保持 FP16 可训
     —— 7B 权重 14GB → 3.5GB，个人单卡微调大模型的标准姿势
  C. AdaLoRA（简化版）：按层增量能量分配秩预算（重要层 r 大），
     对比均匀分配 r —— 自动找甜点，不用手动扫

运行：python3 peft/task3_lora_variants.py
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

torch.manual_seed(42)


# ============ 数据（A 线性预训练 → B 圆分类） ============
def make_data(n, mode):
    x = torch.randn(n, 2)
    if mode == "A":
        y = (x[:, 0] + x[:, 1] > 0).long()
    else:
        y = (x[:, 0] ** 2 + x[:, 1] ** 2 < 1.0).long()
    return x, y

XA_tr, yA_tr = make_data(1000, "A")
XB_tr, yB_tr = make_data(1000, "B")
XB_te, yB_te = make_data(400, "B")


class MLP(nn.Module):
    def __init__(self):
        super().__init__()
        self.f1 = nn.Linear(2, 32)
        self.f2 = nn.Linear(32, 2)
    def forward(self, x):
        return self.f2(F.relu(self.f1(x)))


# ---------- LoRA（Task2 基线） ----------
class LoRALinear(nn.Module):
    def __init__(self, linear, r, alpha=1.0, quant_bits=None):
        super().__init__()
        self.linear = linear
        self.linear.requires_grad_(False)
        self.quant_bits = quant_bits
        if quant_bits:                       # QLoRA：主干量化存储
            self.qw = quantize(linear.weight.detach(), quant_bits).requires_grad_(False)
        self.A = nn.Parameter(torch.randn(linear.in_features, r) * 0.01)
        self.B = nn.Parameter(torch.zeros(r, linear.out_features))
        self.scale = alpha / r
    def forward(self, x):
        W = self.qw if self.quant_bits else self.linear.weight
        return F.linear(x, W, self.linear.bias) + self.scale * (x @ self.A @ self.B)


# ---------- DoRA：方向 × 幅度 ----------
class DoRALinear(nn.Module):
    def __init__(self, linear, r, alpha=1.0, quant_bits=None):
        super().__init__()
        self.linear = linear
        self.linear.requires_grad_(False)
        self.A = nn.Parameter(torch.randn(linear.in_features, r) * 0.01)
        self.B = nn.Parameter(torch.zeros(r, linear.out_features))
        self.m = nn.Parameter(torch.norm(linear.weight, dim=1))  # 幅度 (out,)
        self.scale = alpha / r
    def forward(self, x):
        W = self.linear.weight
        Wd = W + self.scale * (self.A @ self.B).T          # 方向增量
        Wd_n = Wd / (Wd.norm(dim=1, keepdim=True) + 1e-8)  # 单位方向
        return F.linear(x, self.m.unsqueeze(1) * Wd_n, self.linear.bias)


def quantize(w, bits=4):
    """对称 INT4 量化（简化 NF4）：w ≈ round(w/scale)·scale"""
    s = w.abs().max() / (2 ** (bits - 1) - 1)
    q = torch.round(w / s).clamp(-(2 ** (bits - 1) - 1), 2 ** (bits - 1) - 1)
    return q * s


class LoRAMLP(nn.Module):
    def __init__(self, base, r, alpha=1.0, quant_bits=None, dora=False):
        super().__init__()
        cls = DoRALinear if dora else LoRALinear
        r1, r2 = (r, r) if isinstance(r, int) else r     # 支持 (r1, r2) 异秩
        self.f1 = cls(base.f1, r1, alpha, quant_bits)
        self.f2 = cls(base.f2, r2, alpha, quant_bits)
    def forward(self, x):
        return self.f2(F.relu(self.f1(x)))


def pretrain():
    base = MLP()
    opt = torch.optim.Adam(base.parameters(), lr=1e-2)
    for _ in range(300):
        opt.zero_grad()
        loss = F.cross_entropy(base(XA_tr), yA_tr)
        loss.backward(); opt.step()
    return base


def finetune(model, epochs=300, lr=5e-3):
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    for _ in range(epochs):
        opt.zero_grad()
        loss = F.cross_entropy(model(XB_tr), yB_tr)
        loss.backward(); opt.step()
    return (model(XB_te).argmax(-1) == yB_te).float().mean().item()


def n_trainable(m):
    return sum(p.numel() for p in m.parameters() if p.requires_grad)


base = pretrain()
print("=== A. DoRA vs LoRA（同 r=8，圆任务） ===")
acc_lora = finetune(LoRAMLP(MLP(), 8))
acc_dora = finetune(LoRAMLP(MLP(), 8, dora=True))
print(f"  LoRA {acc_lora*100:5.1f}％ vs DoRA {acc_dora*100:5.1f}％"
      f"（DoRA 方向/幅度解耦，可训参数 {n_trainable(LoRAMLP(MLP(),8))}）")

print("\n=== B. QLoRA 模拟：INT4 量化主干 + FP16 增量 ===")
acc_ql = finetune(LoRAMLP(MLP(), 8, quant_bits=4))
err = (LoRAMLP(MLP(), 8).f1.linear.weight - quantize(
    LoRAMLP(MLP(), 8).f1.linear.weight, 4)).abs().max().item()
D_in, D_out = 4096, 14336
print(f"  FP16 主干 LoRA {acc_lora*100:5.1f}％ vs INT4 主干 LoRA(QLoRA) {acc_ql*100:5.1f}％")
print(f"  主干量化误差示例（f1 权重最大差 {err:.2e}）")
print(f"  7B FFN 层显存账本：FP16 {2*D_in*D_out/1e6:.1f} MB vs INT4 {2*D_in*D_out/8/1e6:.1f} MB"
      f"（省 {100-100/8:.0f}％）")

print("\n=== C. AdaLoRA 简化：重要度感知秩分配 ===")
# 用均匀 r=8/8 的 LoRA 训练一次，看每层增量能量
m_probe = LoRAMLP(MLP(), 8)
finetune(m_probe, 300)
e1 = (m_probe.f1.A @ m_probe.f1.B).norm().item() ** 2   # ΔW 能量
e2 = (m_probe.f2.A @ m_probe.f2.B).norm().item() ** 2
total = e1 + e2
print(f"  层能量：f1 {e1:.3f}、f2 {e2:.3f}（f1 占 {e1/total*100:.0f}％）")
# 同总预算 16：均匀 8/8 vs 能量分配（按占比）
r1, r2 = 8, 8
acc_uniform = finetune(LoRAMLP(MLP(), r1, alpha=1.0), 300)
budget = 16
r1a = max(1, round(budget * e1 / total)); r2a = budget - r1a
acc_energy = finetune(LoRAMLP(MLP(), (r1a, r2a)), 300)
print(f"  均匀 r={r1}/{r2} {acc_uniform*100:5.1f}％ vs 能量分配 r={r1a}/{r2a} "
      f"{acc_energy*100:5.1f}％（同预算 16，重要层多分）")

# ============ 断言 ============
assert acc_dora >= acc_lora - 0.03, "DoRA 同 r 下不应明显差于 LoRA（方向/幅度解耦）"
assert acc_ql >= acc_lora - 0.05, "INT4 量化主干 + LoRA 应逼近 FP16（量化误差可被学习补偿）"
assert abs(acc_energy - acc_uniform) < 0.05, "秩分配不劣化效果（AdaLoRA 思路成立）"
print(f"\n[PASS] Task3 全部断言通过：DoRA {acc_dora*100:.1f}％ vs LoRA {acc_lora*100:.1f}％；"
      f"QLoRA {acc_ql*100:.1f}％ vs FP16 {acc_lora*100:.1f}％；"
      f"能量分配 {acc_energy*100:.1f}％ vs 均匀 {acc_uniform*100:.1f}％")

# -*- coding: utf-8 -*-
"""
Task 5 · LoRA 赛道收官：全家桶总账 + 选型决策树
=================================================
Task1-4 实测了 LoRA 家族每个成员。Task5 收官：
  A. 四维总账：参数 / 训练显存 / 每步耗时 / 效果（按真实 7B 规模汇总）
  B. 选型决策树：一个可运行的规则引擎——输入场景特征，输出推荐策略与理由
  C. 断言：关键场景的推荐必须合理（决策树正确性自检）

运行：python3 peft/task5_lora_landscape.py
"""
D_in, D_out, r = 4096, 14336, 8      # 真实 7B FFN 层
FULL = D_in * D_out
LORA = 2 * r * (D_in + D_out)        # up+down 两个 Linear 的 LoRA

print("=== A. LoRA 全家桶四维总账（真实 7B FFN 层口径） ===")
rows = [
    ("全量 FT",       f"{FULL/1e3:.0f}K (100%)", "4x 权重",   "基准",   "100%（上限）"),
    ("LoRA",          f"{LORA/1e3:.0f}K (0.5%)", "+0.3MB 增量", "大模型快", "≈FT（任务相关）"),
    ("QLoRA",         f"{LORA/1e3:.0f}K (0.5%)", "主干 1/8",  "略慢(反量化)", "≈LoRA（误差可补）"),
    ("DoRA",          f"{LORA/1e3:.0f}K+幅度",   "≈LoRA",    "≈LoRA",  "小r/复杂任务略优"),
    ("AdaLoRA",       "自适应(≤预算)",           "≈LoRA",    "≈LoRA",  "同预算不劣化"),
]
print(f"  {'策略':<10}{'可训参数':>18}{'训练显存':>12}{'每步耗时':>12}{'效果':>18}")
for name, p, m, t, e in rows:
    print(f"  {name:<10}{p:>18}{m:>12}{t:>12}{e:>18}")

print("\n=== B. 选型决策树（规则引擎） ===")
def recommend(model_b, vram_gb, conflict, multi_task, budget_ok, complex_task):
    """返回 (策略, 理由)"""
    if model_b < 1:                                    # 小模型
        return "全量 FT", "小模型 LoRA 账本反转（可训参数反超全量），直接 FT"
    if not budget_ok and vram_gb < 24:                 # 显存紧
        return "QLoRA", "4bit 主干 + FP16 增量：7B 权重 14GB→3.5GB，16G 卡可微调"
    if multi_task:
        return "LoRA 多任务", "共享主干 + N 个 ΔW 热切换，任务越多越划算"
    if complex_task and r <= 8:
        return "DoRA", "方向/幅度解耦，小秩下比 LoRA 稳，逼近全量微调动力学"
    if conflict:                                       # 任务强冲突
        return "全量 FT", "强冲突任务 LoRA 也救不了遗忘，且 FT 容量上限更高"
    return "LoRA", "任务相关 + 显存够：低秩增量逼近 FT，参数省 99%"

cases = [
    ("小模型 0.5B",        dict(model_b=0.5, vram_gb=8,   conflict=False, multi_task=False, budget_ok=True,  complex_task=False)),
    ("7B·16G·QLoRA场景",   dict(model_b=7,   vram_gb=16,  conflict=False, multi_task=False, budget_ok=False, complex_task=False)),
    ("7B·40G·多任务",      dict(model_b=7,   vram_gb=40,  conflict=False, multi_task=True,  budget_ok=True,  complex_task=False)),
    ("7B·40G·任务相关",    dict(model_b=7,   vram_gb=40,  conflict=False, multi_task=False, budget_ok=True,  complex_task=False)),
    ("7B·40G·强冲突",      dict(model_b=7,   vram_gb=40,  conflict=True,  multi_task=False, budget_ok=True,  complex_task=False)),
    ("7B·40G·复杂任务小r", dict(model_b=7,   vram_gb=40,  conflict=False, multi_task=False, budget_ok=True,  complex_task=True)),
]
for name, kw in cases:
    s, why = recommend(**kw)
    print(f"  {name:<16} → {s:<12}｜{why}")

# ============ C. 断言（决策树正确性） ============
assert recommend(0.5, 8, False, False, True, False)[0] == "全量 FT"
assert recommend(7, 16, False, False, False, False)[0] == "QLoRA"
assert recommend(7, 40, False, True, True, False)[0].startswith("LoRA 多任务")
assert recommend(7, 40, False, False, True, False)[0] == "LoRA"
assert recommend(7, 40, True, False, True, False)[0] == "全量 FT"
assert recommend(7, 40, False, False, True, True)[0] == "DoRA"
print(f"\n[PASS] Task5 全部断言通过：6 个关键场景的选型推荐全部合理")

print("""
--- LoRA 赛道收官 ---
  Task1 全量 vs LoRA：低秩增量逼近 FT；冲突任务谁都遗忘（LoRA 无魔法）
  Task2 秩与 target：甜点 r=8~64；位置因任务而异；merge 数学恒等；多任务共享
  Task3 变体：DoRA（幅度/方向解耦）、QLoRA（量化主干省 88%）、AdaLoRA（自动找秩）
  Task4 端到端：mini-LLM 实测——15.4% 参数逼近 FT；冲突面决定遗忘
  Task5 选型：小模型 FT / 显存紧 QLoRA / 多任务 LoRA / 强冲突 FT / 小秩复杂 DoRA
  一句话：LoRA = 用低秩增量换"参数、显存、多任务"三重便宜，用选型换"别翻车"。
""")
